Author: Daniela Pereira Rigoli

# Rainbow-Schools
Phase 1 - C Sharp Basic

Retrieve Student Data from a Text File

## DESCRIPTION

A program that will retrieve student data from a text file and display it. The file should be “records.txt” and should be in the same folder that will execute the program. 

### This program: 

Have a simple menu, with two options, retrieve student data from a text file and exit. If the user choose the option 1, will appear what have in the file. If the user write something different from ‘1’ and ‘0’, will appear that is a invalid option. And if the user write ‘0’ will close the program. 

### Background of the problem statement:

As part of the prototyping process of developing software for Rainbow Schools, they need a simple system where students’ data can be stored in a text file and then be displayed on screen.

### Text file: 
Simple text file created externally using Notepad and pre-populated with data

### Environment:
Visual Studio Windows Console Project

.NETFramework,Version=v4.7.2

### Data format:

The text will be updated with data offline, using a notepad or text editor.

